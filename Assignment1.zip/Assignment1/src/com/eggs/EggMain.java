package com.eggs;

public class EggMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        CalculateEgg calc= new CalculateEgg();
        calc.setTotalNoOfEggs(200);
        calc.calculateEggs();
	}

}
