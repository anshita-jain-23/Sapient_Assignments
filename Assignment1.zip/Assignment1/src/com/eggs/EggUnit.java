package com.eggs;

public class EggUnit {
	int gross;
	int dozens;
	int remaining;
	public int getGross() {
		return gross;
	}
	public void setGross(int gross) {
		this.gross = gross;
	}
	public int getDozens() {
		return dozens;
	}
	public void setDozens(int dozens) {
		this.dozens = dozens;
	}
	public int getRemaining() {
		return remaining;
	}
	public void setRemaining(int remaining) {
		this.remaining = remaining;
	}
}
